@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (echo 请先安装 Node.js 24 LTS & pause & exit /b 1)
echo 浏览器打开 http://127.0.0.1:3000/
node server/server.mjs --standalone
pause
