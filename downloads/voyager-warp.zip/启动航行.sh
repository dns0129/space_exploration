#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "Open http://127.0.0.1:3000/ after the server starts."
exec node server/server.mjs --standalone
